import os, json

filename='settings.json'
default = {
    'allowlist': [],
    'time_out': 20
}

def load()->dict:
    result = default
    if os.path.exists(filename):
        with open(filename, encoding='utf-8') as f:
            result = json.loads(f.read())
    return result

def save(args:dict):
    with open(filename, mode='w', encoding='utf-8') as f:
        f.write(json.dumps(args))
