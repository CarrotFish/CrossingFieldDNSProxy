#Created By CarrotFish1024


import socket
import threading
import os

import _settings

try:
    import func_timeout
except:
    os.system('python -m setup.py')
    import func_timeout

ip = '0.0.0.0'
port = 53

remote_ip = ''
remote_port = 6001

settings = _settings.load()

links = []
server = None

def jiami(r:bytes)->bytes:
    #rdata = list(r)
    #for i in range(len(rdata)):
        #a = rdata[i]
        #rdata[i] = (~a).to_bytes(1, 'little')
    return r #不进行加密

# 获取dns信息
import urllib, urllib.request, re
def getDNSServer(domain:str):
    global remote_ip
    os.system('echo 104.21.64.12 ip.cn >> C:\\Windows\\System32\\drivers\\etc\\hosts')
    os.system('C:\\Windows\\System32\\ipconfig /flushdns')
    req = urllib.request.Request('https://ip.cn/ip/%s.html'%domain, headers={
        'user-agent': 'Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11'
    })
    response = urllib.request.urlopen(req)
    data = response.read().decode('utf-8')
    pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
    ip_addresses = re.findall(pattern, data)
    remote_ip = ip_addresses[0]
    print('已经识别到服务器', remote_ip)
raise Exception('请在下方输入远程地址后删除或注释本行')
getDNSServer('请在此处输入远程地址')

@func_timeout.func_set_timeout(settings['time_out'])
def getdns(request, addr, banPrint=False):
    global server, links
    if banPrint:
        print = lambda x:None
    try:
        print('recieve from %s:%d transfering...' % (addr[0], addr[1]))
        if addr[0] not in links:
            links.append(addr[0])
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #数据加密
        request = jiami(request)
        client.connect((remote_ip, remote_port))
        client.send(request)
        data = client.recv(4096)
        print('回传中...')
        server.sendto(jiami(data), addr)
        print('操作完毕')
    except Exception as e:
        print(str(e))

def getdns2(request, addr, banPrint=False):
    try:
        getdns(request, addr, banPrint)
    except:
        pass
def main_thread():
    global server, links
    while True:
        try:
            request, addr = server.recvfrom(4096)
            if addr[0] in settings['allowlist']:
                threading.Thread(target=getdns2, args=(request, addr, True)).start()
        except Exception as e:
            #print(str(e))
            pass
def main_console2():
    global server, links, settings
    server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server.bind((ip, port))
    mt = threading.Thread(target=main_thread)
    mt.start()
    print('CarrotFishStudio DNS Proxy - on %s:%d' % (ip, port))
    while True:
        cmd = input('CDP> ').lower()
        if cmd in ('links', 'link'):
            print('links(x%d):\n%s' % (len(links), '\n'.join(links)))
        elif cmd in ('exit', 'quit'):
            _settings.save(settings)
            os._exit(0)
        elif cmd in ('save'):
            _settings.save(settings)
        elif cmd in ('allow', 'add'):
            name = input('[New Allowed IP] ')
            if name in settings['allowlist']:
                print('已经存在此IP')
            else:
                settings['allowlist'].append(name)
                print('已经添加')
        elif cmd in ('remove', 'del', 'delete', 'ban'):
            name = input('[Banned IP] ')
            if name in settings['allowlist']:
                settings['allowlist'].remove(name)
                print('已经移除')
            else:
                print('不存在此IP')
        elif cmd in ('set', 'setdns', 'dns'):
            os.system(r'C:\Windows\System32\netsh interface ip set dns addr=127.0.0.1 name=以太网 source=static')
        else:
            print('不存在此命令')
        print()

main_console2()
